<!DOCTYPE html>
<html lang="en">
<?php include 'php_includes/database_connection.php'; ?>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
    crossorigin="anonymous">
  <link rel="stylesheet" href="css/styles.css">
  <title>Bootstrap Theme</title>
</head>

<body>
  <!-- Navbar -->
  <nav class="fixed-top navbar navbar-expand-sm bg-light navbar-light" id="main-nav">
    <div class="container">
      <a href="index.html" class="navbar-logo"><img src="img/Zoaki.png" width="70" heigh="70" alt="" class="logo-img logo-img2"></a>
      <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">  
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="#home" class="nav-link">Home</a>
          </li>
          <li class="nav-item active">
            <a href="#explore-head-section" class="nav-link">Miss&Found</a>
          </li>
          <li class="nav-item">
            <a href="#create-head-section" class="nav-link">Information</a>
          </li>
          <li class="nav-item">
            <a href="#share-head-section" class="nav-link">About</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- START HERE -->
  <!-- Type Your code below. -->
  <div class="jumbotron" style="margin-top:40px">
  <?php include 'php_includes/missfound.php'; ?>
    <h1 class="text-center"><i class="fas fa-paw jumb-icon mr-2"></i>They need your help<i class="fas fa-paw jumb-icon"></i></h1>
    <p class="lead text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit nulla totam quia nobis beatae voluptates possimus porro animi temporibus repudiandae asperiores nisi, eum consequuntur, saepe provident reiciendis fugiat cupiditate quis ut! In autem facere dignissimos dolorem nobis officia quae architecto modi! Veniam, molestias nam! Veritatis fuga inventore dignissimos sapiente voluptate velit consectetur, ipsam aliquid ex eos id nobis vel similique.</p>
  </div>

  <div class="container" style="margin-top:30px">
    <div class="row mb-2">
      <div class="col-md-3">
          <span class="mb-2 position-fixed btn-sub" style="z-index: 999; right: 30px; bottom: 30px" data-toggle="modal" data-target="#formModal">
              <button type="button" class="btn btn-primary pull-right  btn-sub" style="">
                  <i class="fas fa-edit"></i>
              </button>
          </span>
      </div>
      <div class="col-md-9"></div>
    </div>
    <div class="row">
    <?php include 'php_includes/print_card.php'; ?>     
    </div>
  </div>       


  <div class="container">
    <nav aria-label="Page navigation">
      <ul class="pagination justify-content-center">
      <?php include 'php_includes/pagination.php'; ?>   
      </ul>
    </nav>
  </div>

    <!-- Contact Modal -->
    <div id="formModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title float-left">Contact</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <div class="modal-body">
                  <form method="post" enctype="multipart/form-data" action="">
                     <div class="form-row align-items-center">
                       <div class="col-sm-6 my-1">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <div class="input-group-text"><i class="fas fa-address-book"></i></div>
                          </div>
                          <input type="text" class="form-control" placeholder="Your Name" name="user_name">
                        </div>
                       </div>
                       <div class="col-sm-6 my-1">
                          <div class="input-group">
                            <div class="input-group-prepend">
                              <div class="input-group-text"><i class="fas fa-phone-volume"></i></div>
                            </div>
                            <input type="text" class="form-control" placeholder="Your Phone#" name="user_phone">
                          </div>
                        </div>
                     </div>
                     <div class="form-row">
                       <div class="col-sm-12 my-1">
                         <div class="input-group">
                           <div class="container">
                              <input type="file" name="image" />
                           </div>
                         </div>
                       </div>
                     </div>
                     <div class="form-row">
                        <div class="col-sm-6 my-1">
                            <div class="input-group">
                              <div class="input-group-prepend">
                                <div class="input-group-text"><i class="fas fa-paw"></i></div>
                              </div>
                              <input type="text" class="form-control" placeholder="Breed Type" name="pet_type">
                            </div>
                        </div>
                        <div class="col-sm-6 my-1">
                            <div class="input-group">
                              <div class="input-group-prepend">
                                <div class="input-group-text"><i class="fas fa-info-circle"></i></div>
                              </div>
                              <!-- <input type="text" class="form-control" placeholder="Sex" name="pet_gender"> -->
                              <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="pet_status">
                                <option selected>Found/Missing</option>
                                <option value="Found">Found</option>
                                <option value="Miss">Missing</option>
                              </select>
                            </div>
                        </div>
                     </div>
                     <div class="form-row">
                        <div class="col-sm-6 my-1">
                            <div class="input-group">
                              <div class="input-group-prepend">
                                <div class="input-group-text"><i class="fas fa-transgender"></i></div>
                              </div>
                              <!-- <input type="text" class="form-control" placeholder="Sex" name="pet_gender"> -->
                              <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="pet_gender">
                                <option selected>Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                              </select>
                            </div>
                        </div>
                        <div class="col-sm-6 my-1">
                            <div class="input-group">
                              <div class="input-group-prepend">
                                <div class="input-group-text"><i class="fas fa-crow"></i></div>
                              </div>
                              <input type="text" class="form-control" placeholder="Age" name="pet_age">
                            </div>
                        </div>
                     </div>
                     <div class="from-row">
                        <div class="col-sm-12 my-1">
                          <div class="input-group">
                            <div class="input-group-prepend">
                              <div class="input-group-text"><i class="fas fa-pencil-alt"></i></div>
                            </div>
                            <textarea id="" rows="3" cols="12" class="form-control" name="pet_info"></textarea>
                          </div>
                        </div>
                     </div>
                     <button class="btn btn-primary float-right mt-1 btn-sm" name="submit" type="submit">Submit</button>
                  </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
              </div>
          </div>
        </div>
      </div>

</div>


























  <!-- Footer -->
  <div class="gap"></div>
  <footer id="main-footer" class="bg-light">
    <div class="container">
      <div class="row">
        <div class="col text-center py-4">
          <h3>Demo1</h3>
          <p>Copyright &copy; <span id="year"></span></p>
        </div>
      </div>
    </div>
  </footer>

  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>

  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());

    //configure slider
    $('.carousel').carousel({
      interval: 6000,
      pause: 'hover'
    });

    //comfirmation alert
    function confirmalert(){
      alert("Thanks For Your Help!!!");
    }


  </script>
</body>

</html>
