<?php
if(isset($_POST['submit'])){
    $user_name = $_POST['user_name'];
    $user_phone = $_POST['user_phone'];
    $error_img="";
    if($_FILES['image']) {
        $user_img = $_FILES['image']['name'];
        $user_img_temp = $_FILES['image']['tmp_name'];
        move_uploaded_file($user_img_temp,"./user_uploaded_img/$user_img");
    }else {
        $user_img = "default.jpeg";
    }
    $pet_status = $_POST['pet_status'];
    $pet_type = $_POST['pet_type'];
    $pet_gender = $_POST['pet_gender'];
    $pet_age = $_POST['pet_age'];
    $pet_info = $_POST['pet_info'];
    $post_date = date('d-m-y');
    $statu = "approve";

    $query = "INSERT INTO foundmiss(user_name,user_phone,user_img,pet_status,pet_type,pet_sex,pet_age,pet_info,post_date,statu) ";
    $query .= "VALUES('{$user_name}','{$user_phone}','{$user_img}','{$pet_status}','{$pet_type}','{$pet_gender}','{$pet_age}','{$pet_info}',now(),'{$statu}')";

    $insert_query = mysqli_query($con, $query);
    $msg="submitted";
    echo $msg;
}
?>